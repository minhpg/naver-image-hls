
const getParams = (name, url) => {
    if (!url) url = location.href;
    name = name.replace(/[\[]/,"\\\[").replace(/[\]]/,"\\\]");
    var regexS = "[\\?&]"+name+"=([^&#]*)";
    var regex = new RegExp(regexS);
    var results = regex.exec(url);
    return results == null ? null : results[1];
}

const initPlayer = (link) =>  {
    let player = jwplayer("player");
    let object = {
        playbackRateControls: [0.75, 1, 1.25, 1.5, 2],
        controls: true,
        volume: 75,
        stretching: "uniform",
        width: "100%",
        height: "100%",
        file: link,
        type: "hls",
        preload: "auto",
        // image: `/embed/thumbnail/${id}`,
        skin: {
            name:'animevsub',
            url: '/static/animevsub.css',
        }
    };
    player.setup(object);
    player.addButton("/static/icons/skip-forward.svg", "Skip OP/ED", function() {
        skip_time = player.getPosition() + 90;
        player.seek(skip_time)
    }, "skipButton");
    player.addButton("/static/icons/forward.svg", "Tua tiếp 5s", function() {
        player.seek(player.getPosition() + 5);
    }, "Tua tiếp 5s");
    player.addButton("/static/icons/backward.svg", "Tua lại 5s", function() {
        player.seek(player.getPosition() - 5);
    }, "Tua lại 5s");
    if (Hls.isSupported() && p2pml.hlsjs.Engine.isSupported()) {
        var engine = new p2pml.hlsjs.Engine();
        jwplayer_hls_provider.attach();
        p2pml.hlsjs.initJwPlayer(player, {
            liveSyncDurationCount: 7, // To have at least 7 segments in queue
            loader: engine.createLoaderClass(),
        });
    }
    player.on('ready', function() {
        $('#loading').hide(300);
    });
}

const getInfo = () => {
    return new Promise((resolve, reject) => {
        initPlayer(`/playlist/${id}/playlist.m3u8`)
    })
}
getInfo().catch((err) => {
    showError(err);
})